



<table class="table table-responsive table-striped">

  <thead class="table-dark" style="text-align: center">
      <tr>
      <th>Id</th>
      <th>Name</th>
      <th>Email</th>
      <th colspan="2">Operation</th>

      </tr>
  </thead>


  <tbody style="text-align: center">
    <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($record->id); ?></td>
        <td><?php echo e($record->name); ?></td>
        <td><?php echo e($record->email); ?></td>
        <td><button class="btn btn-warning editbtn" data-id="<?php echo e($record->id); ?>">Edit</button></td>
        <td><button class="btn btn-danger delbtn"  data-id="<?php echo e($record->id); ?>">Delete</button></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>




</table>









<?php /**PATH C:\xampp\htdocs\laravelproject\ajaxcrudb\resources\views/show.blade.php ENDPATH**/ ?>