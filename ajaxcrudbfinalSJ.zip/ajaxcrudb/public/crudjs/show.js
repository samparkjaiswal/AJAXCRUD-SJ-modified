$(document).ready(function() {
     init();

     remove();

    editrow();

    updatedata();


});


//for show data in view multiple ways (get view via ajax OR Datatable{set search or other params set false} OR use apeand method direct dispaly data or load view)

 function init()
{
    $.ajax({
        // url: 'http://127.0.0.1:8000/showdata',   //ye tarika static hai
        url: 'showdata',
        type: "GET",
        success: function (result) {
            // console.log(result);
            // return;
            $('#fetchdata').append(result.html);  //update view page loa

        },

    });


}




//this function is called at time of document load
function remove()
{
     // $('.editbtn').on('click', function(e) {   //in this case that way is not work for calling event
     $(document).on('click',".delbtn",function (e) {    //this way is worked nice
        e.preventDefault();
        var id = $(this).data("id");
        // alert(id);
        // return;
    //    console.log(id);
        $.ajax({
            // url: "http://127.0.0.1:8000/deleterow/"+id,   //it's not better way
            url: "deleterow/"+id,
            type: "GET",
            success: function(result) {
                console.log(result);
                location.reload(true);

                // $('#msg').removeClass('d-none');   //msg show
                // $('#msg #msgshow').html(result.success);

            },
            error: function (error) {
                console.log(error)

                // $('#msgdiv').removeClass('d-none');

                // $('#msg').html(result.error);


            }


        })

    });
}






// this function is called at time of documnent load

  function editrow() {

    // $('.editbtn').on('click', function(e) {    //both way is worked
        $(document).on('click', '.editbtn', function(e) {     //this way is best way for fire event
        e.preventDefault();
        // alert('hello');
        // return
        var id = $(this).data('id');
        // alert(id);

       $.ajax({
            type: "get",
            // url: "http://127.0.0.1:8000/edit/"+id,
            url: "edit/"+id,
            // data: "data"
            success: function (result) {

                $('body').html(result.html);   //load view from response data(update page view load)
                // console.log(result);
                // $('.editpage').append(result);

            }
        });
    })
  }




  function updatedata()
  {
    // $('.updatebtn').on('click', function(e) {
        $(document).on('click', '.updatebtn', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        // alert(id);
        var csrf_token = $("#csrf").val();

        var name = $('#Name').val();
        var email = $('#Email').val();

        // console.log(name);
        // return;


       $.ajax({
        type: "POST",
        // url: "http://127.0.0.1:8000/update/"+id,
        url: "update/"+id,
        data: {
            "_token": csrf_token,
            "name": name,
            "email": email
        },
        success: function (result) {
            // alert(result);
            console.log(result);
            location.reload();

        },
        error: function(error)
        {
            console.log(error);
        }
       })


    })

    $(document).on('click','#closebtn' , function() {    //custome create for msg display for close button
        $(this).parent().addClass('d-none');
    })



  }
