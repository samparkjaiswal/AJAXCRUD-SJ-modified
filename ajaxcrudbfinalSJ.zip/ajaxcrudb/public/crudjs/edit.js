$(document).ready(function() {
    // $('.editbtn').on('click', function(e) {   //both way we call event
    $(document).on('click', '.editbtn', function(e) {    //this is best way to call event
        e.preventDefault();
        var id = $(this).data('id');
        // alert(id);

       $.ajax({
            type: "get",
            // url: "http://127.0.0.1:8000/edit/"+id,
            url: "edit/"+id,
            // data: "data"
            success: function (result) {

                $('body').html(result.html);   //load view from response data(update page view load)
                // console.log(result);
                // $('.editpage').append(result);

            }
        });
    })


    // $('.updatebtn').on('click', function(e) {
    //     e.preventDefault();
    //     var id = $(this).data('id');
    //     alert(id);
    //     var csrf_token = $("#csrf").val();

    // })



})
