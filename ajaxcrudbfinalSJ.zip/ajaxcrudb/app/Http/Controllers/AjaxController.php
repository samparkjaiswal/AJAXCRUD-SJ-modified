<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Hamcrest\Core\IsTypeOf;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Symfony\Component\HttpFoundation\Session\SessionInterface;

class AjaxController extends Controller
{
    public function formview()
    {
        
        return view('Register');
    }

    public function insert(Request $request)
    {

        $student = new Student();

        $student->name = $request->name;
        $student->email = $request->email;
        $student->password = $request->password;

        $student->save();

        if($student)
        {

        //   $status =  $request->session()->flash('success', 'Registration successful!'); //its work when we reload the page via ajax(but not better approach)


            return response()->json(['success' => 'Registration success'], 200);  //best way to return response with msg

            // return $student; //worked but not better approach

            // return response()->json($student);  //worked better but not better approach

        }
        else
        {
            // $status =  $request->session()->flash('fail', 'Something error!, try after sometimes.');


            return response()->json(['error' => 'something went wrong!'], 400);

        }
        // return response()->json($status);

    }

    public function showindex()
    {
        return view('showfirst');
    }


    public function showdata()
    {



        $records = Student::all();

        // dd($record);
        // return response()->json($record, 200);
        $row = view('show',compact('records'))->render();

        // response()->json(['msg'=>'Updated Successfully', 'success'=>true, 'data'=>$data]);
        return response()->json(['html'=>$row], 200);
    }


    public function delrow($id)
    {
       $delrecord = Student::where('id', $id)->delete();


       if($delrecord)
       {
        return response()->json(['success' => 'Record Deleted'], 200);

       }

    }

    public function editview($id)
    {
        $editdata = Student::where('id', $id)->first();

        if($editdata)
        {
            $dataview = view('editview',compact('editdata'))->render();
            return response()->json(['html'=>$dataview], 200);
        }
    }


    public function updatedata(Request $request, $id)
    {
        $update = Student::where('id', $id)->first();

        $update->name = $request->name;
        $update->email = $request->email;

       $row = $update->update();

       if($row)
       {
        // session()->flash('success', 'Record Update successfully');
        Session::flash('successfull', 'Record update');

        return response()->json([Session::get('successfull')], 200);

        // return response()->json(['success'=> 'Record Update success'], 200);
       }
       else
       {

        Session::flash('error', 'Record not update');

        return response()->json([Session::get('error')], 400);
        // return response()->json(['failed'=> 'Update Failed'], 400);
       }

        // return 'hello';
    }



}
