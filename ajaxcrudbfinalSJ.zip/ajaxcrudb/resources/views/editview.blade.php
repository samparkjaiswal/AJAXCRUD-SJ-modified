

    <div class="container">
        <div class="row">
            <div class="col-md-12">


                <form action="" class="editpage" method="POST" autocomplete="off" id="updatefrm" >

                    <input type="hidden" name="_token" id="csrf" value="{{ csrf_token() }}">

                    {{-- <input type="hidden" > --}}


                    <div class="form-group">
                      <label for="">Name</label>
                      <input type="text" name=""  class="form-control" id="Name" placeholder="" value="{{ $editdata->name }}" aria-describedby="helpId">
                        <span></span>
                    </div>

                    <div class="form-group">
                        <label for="">Email</label>
                        <input type="text" name="" class="form-control" id="Email" placeholder="" value="{{ $editdata->email }}" aria-describedby="helpId">
                          <span></span>
                      </div>

                      <button class="btn btn-success updatebtn" data-id={{ $editdata->id }}>Update Data</button>

                </form>
            </div>
        </div>
    </div>

    {{-- <script>
         $('.updatebtn').on('click', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        alert(id);
        var csrf_token = $("#csrf").val();

    //    console.log(id);
    })
    </script> --}}
